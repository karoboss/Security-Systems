# Buffer Overflow Exploitation

## Project Details:

- Developers:
  - Georgios Michail Siatras (2019030033)
  - Andreas Karogiannis (2019030064)
  
- Course: Security of Systems and Services
- Professor: Sotirios Ioannidis
- University: Technical University of Crete

## Steps Taken:

1. Buffer Overflow Discovery

We initiated a buffer overflow by providing a long string of 'A's, causing an overflow at address 0x41414141.

2. Shellcode Selection

To execute arbitrary code, we obtained shellcode from [shell-storm.org/shellcode](https://shell-storm.org/shellcode/).
We created a test_shellcode that opened a bin/sh terminal.

3. Exploit File Creation

Following a tutorial ([link](https://www.youtube.com/watch?v=hJ8IwyhqzD4)), we created an exploit file.
We identified the buffer address and determined the appropriate stack length (48).
However, we noticed that the shellcode was overwritten by a counter of for loop before execution, trying to possition the shellcode so that it doesnt get overwritten and fill with some nop \x90.

4. 

Found a workaround by running the exploit as follows:
(python3 exploit.py; cat) | ./Greeter
