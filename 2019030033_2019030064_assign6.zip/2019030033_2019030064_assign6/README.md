# Intrusion Detection Systems (IDS) Overview

Developed by Georgios Michail Siatras (2019030033) and Andreas Karogiannis(2019030064)	

TUC: Security of Systems and Services			

Proffessor: Sotirios Ioannidis				

## ICMP Connection Attempt
- **Description:** An alert is triggered for every ICMP connection attempt.
- **Results:** Captured all ICMP connections.
  

## Hello String Detection
- **Description:** An alert is set to detect the content "hello" in TCP packets.
- **Results:**
   1. 01/25-20:55:11.233990 - [1:1000002:0] Hello String Detected - {TCP} 70.37.129.34:80 -> 10.0.2.15:2553
   2. 01/25-20:57:01.233990 - [1:1000002:0] Hello String Detected - {TCP} 70.37.129.34:5480 -> 10.0.2.15:2553

## Traffic Between Non-Root Ports
- **Description:** An alert is set to detect traffic for ports 1025 and above.
- **Results:** Multiple instances of detected traffic.

## SSH Brute Force Attacks
- **Description:** Alert is set to detect traffic to port 22 (SSH port). Thresholding is applied to both source and destination IPs, tracking by source, with a count of 10 events triggering the alert within 60 seconds.
- **Results:**
   1. 03/30-16:44:49.230103 - [1:1000004:1] SSH Brute-Force attack Detected - {TCP} 192.168.56.1:55470 -> 192.168.56.103:22
   2. 03/30-16:45:49.925357 - [1:1000004:1] SSH Brute-Force attack Detected - {TCP} 192.168.56.1:55479 -> 192.168.56.103:22

## Malicious Traffic Detected

### 1. IIS Access with %2E-asp
- **Signature ID:** 1:972:8
- **Classification:** Access to a potentially vulnerable web application
- **Priority:** 2 (medium)
- **Details:** Source IP 172.16.255.1 is connecting to 204.194.237.136 on port 80 with a request involving %2E-asp.

### 2. SNMP Access
- **Signature IDs:** 1:1411:10, 1:1417:9
- **Classification:** Attempted Information Leak
- **Priority:** 2 (medium)
- **Details:** Indicates SNMP (Simple Network Management Protocol) public access and request attempts. Source IP 192.168.3.131 is connecting to 192.168.3.99 on port 161.

### 3. ICMP Activities
- **Signature ID:** 1:485:4, 1:466:4
- **Classification:** Misc activity, Attempted Information Leak
- **Priority:** 2 (medium)
- **Details:** Indicates ICMP activities, including destination unreachable and L3retriever ping. Communications between various IP addresses are observed.

### 4. Web Application Attack - mod_jrun Overflow Attempt
- **Signature ID:** 1:100000122:1
- **Classification:** Web Application Attack
- **Priority:** 1 (HIGH)
- **Details:** Indicates an attempt to exploit a potential overflow vulnerability in the mod_jrun module. Source IP 10.0.2.15 is connecting to 65.54.167.27 on port 80.

### 5. Chat MSN Activity
- **Signature IDs:** 1:1990:1, 1:540:11
- **Classification:** Potential Corporate Privacy Violation
- **Priority:** 1 (HIGH)
- **Details:** Indicates MSN-related chat activities, including user search and message activities. Source IP 10.0.2.15 is communicating with 64.4.35.57 on port 1863.


